//
// Created by Pavel Akhtyamov on 2019-02-25.
//

#pragma once

#include "Room.h"

class NormalRoom : public Room {
 public:
  virtual ~NormalRoom() = default;
};

