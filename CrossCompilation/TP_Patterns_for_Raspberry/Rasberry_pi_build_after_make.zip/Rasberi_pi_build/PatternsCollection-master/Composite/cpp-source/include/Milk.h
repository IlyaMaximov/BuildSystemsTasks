//
// Created by Pavel Akhtyamov on 2019-03-26.
//

#pragma once

#include "DishComponent.h"
class Milk : public DishComponent {
  size_t GetCalories() override;
};



